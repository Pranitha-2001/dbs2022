import React from 'react'

const FailMessage = () => {
    return (
        <div>
            <center>
            <label>Invalid Credentials !</label>
            </center>
        </div>
    )
}

export default FailMessage
