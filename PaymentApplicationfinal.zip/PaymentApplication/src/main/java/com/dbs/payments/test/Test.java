package com.dbs.payments.test;

import com.dbs.payments.app.model.BankDetails;

public class Test {

	public static void main(String[] args) {
		
	BankDetails bd=new BankDetails();

	}

}
